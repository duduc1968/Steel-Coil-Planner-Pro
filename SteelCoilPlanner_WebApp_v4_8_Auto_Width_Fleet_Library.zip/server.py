from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.io.cargo_reader import read_cargo
from app.core.planner import make_plan, summary
from app.core.geometry import PATTERN_LABELS
from app.reports.drawing import draw_plan
from app.reports.weight_report import block_weight_summary

ROOT = Path(__file__).parent
UPLOADS = ROOT / "uploads"
RESULTS = ROOT / "results"
SHIPS = ROOT / "config" / "ships"
UPLOADS.mkdir(exist_ok=True)
RESULTS.mkdir(exist_ok=True)
SHIPS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Steel Coil Planner Pro")

@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")

app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
app.mount("/results", StaticFiles(directory=RESULTS), name="results")

def to_float(value: str):
    return float(str(value).replace(",", "."))


class ShipHold(BaseModel):
    ship_name: str = Field(..., min_length=1)
    hold_name: str = Field("Hold 1")
    hold_width_m: float
    hold_length_m: float
    hold_depth_m: float | None = None
    max_stack_height_m: float | None = None
    tank_top_limit_t_m2: float | None = None
    bilge_radius_m: float | None = None
    hopper_angle_deg: float | None = None
    hatch_opening_width_m: float | None = None
    frame_spacing_m: float | None = None
    coil_diameter_m: float = 1.8
    row_gap_m: float = 0.15
    center_gap_m: float = 0.70
    stowage_pattern: str = "auto_width_wedge"

class ShipConfig(BaseModel):
    ship_name: str = Field(..., min_length=1)
    holds: list[ShipHold] = Field(default_factory=list)

def ship_file_name(name: str) -> str:
    safe = ''.join(ch if ch.isalnum() or ch in ('-', '_') else '_' for ch in name.strip())
    return safe[:80] or 'ship'

def normalize_ship_data(data: dict) -> dict:
    # v4.8 library format: one ship with multiple holds.
    # Legacy v4.2/v4.7 files saved one hold directly; keep them readable.
    if 'holds' not in data:
        hold = dict(data)
        ship_name = hold.get('ship_name', 'Unnamed ship')
        data = {'ship_name': ship_name, 'holds': [hold]}
    for h in data.get('holds', []):
        h.setdefault('ship_name', data.get('ship_name', 'Unnamed ship'))
        h.setdefault('hold_name', 'Hold 1')
        h.setdefault('stowage_pattern', 'auto_width_wedge')
    return data

def load_ship_files():
    import json
    ships = []
    for f in sorted(SHIPS.glob('*.json')):
        try:
            data = normalize_ship_data(json.loads(f.read_text(encoding='utf-8')))
            data['_file'] = f.name
            ships.append(data)
        except Exception:
            continue
    return ships

@app.get('/api/ships')
def list_ships():
    return {'ships': load_ship_files()}

@app.post('/api/ships')
async def save_ship(payload: dict):
    import json
    data = normalize_ship_data(dict(payload))
    # validate each hold and keep a clean JSON file
    clean_holds = []
    for h in data.get('holds', []):
        h = dict(h)
        h['ship_name'] = data.get('ship_name') or h.get('ship_name') or 'Unnamed ship'
        clean_holds.append(ShipHold(**h).model_dump())
    data = {'ship_name': data.get('ship_name') or clean_holds[0]['ship_name'], 'holds': clean_holds}
    path = SHIPS / f"{ship_file_name(data['ship_name'])}.json"
    path.write_text(json.dumps(data, indent=2), encoding='utf-8')
    return {'status': 'saved', 'ship': data, 'file': path.name}

@app.delete('/api/ships/{file_name}')
def delete_ship(file_name: str):
    path = SHIPS / Path(file_name).name
    if not path.exists():
        raise HTTPException(status_code=404, detail='Ship file not found.')
    path.unlink()
    return {'status': 'deleted', 'file': path.name}

@app.post("/import-cargo")
async def import_cargo(cargo_file: UploadFile = File(...)):
    """Read cargo only, normalize units, and return a preview before planning."""
    try:
        suffix = Path(cargo_file.filename).suffix.lower()
        if suffix not in [".csv", ".xlsx", ".xls", ".pdf"]:
            raise HTTPException(status_code=400, detail="Please upload CSV/XLSX/PDF file.")
        job_id = uuid4().hex[:10]
        upload_path = UPLOADS / f"preview_{job_id}{suffix}"
        upload_path.write_bytes(await cargo_file.read())
        cargo = read_cargo(upload_path)

        # Same unit conversion logic as planner, for preview only.
        import pandas as pd
        def series_to_m(values):
            x = pd.to_numeric(values, errors="raise")
            return x.where(x <= 20, x / 1000)
        def series_to_t(values):
            x = pd.to_numeric(values, errors="raise")
            return x.where(x <= 200, x / 1000)

        cargo = cargo.copy()
        cargo["Width_m"] = series_to_m(cargo["Width"])
        cargo["Weight_t"] = series_to_t(cargo["Weight"])
        if "Diameter" in cargo.columns and cargo["Diameter"].notna().any():
            cargo["Diameter_m"] = series_to_m(cargo["Diameter"])
        cargo = cargo.sort_values([c for c in ["Diameter_m", "Weight_t", "Width_m"] if c in cargo.columns], ascending=False).reset_index(drop=True)
        rows = cargo[[c for c in ["ID", "Width_m", "Weight_t", "Diameter_m"] if c in cargo.columns]].head(200).to_dict("records")
        return {
            "filename": cargo_file.filename,
            "coil_count": int(len(cargo)),
            "total_weight_t": float(cargo["Weight_t"].sum()),
            "max_width_m": float(cargo["Width_m"].max()),
            "max_diameter_m": float(cargo["Diameter_m"].max()) if "Diameter_m" in cargo.columns else None,
            "coils": rows,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/calculate")
async def calculate(
    ship_name: str = Form(...),
    hold_name: str = Form(...),
    hold_width_m: str = Form(...),
    hold_length_m: str = Form(...),
    coil_diameter_m: str = Form(...),
    row_gap_m: str = Form(...),
    max_stack_height_m: str = Form(""),
    tank_top_limit_t_m2: str = Form(""),
    center_gap_m: str = Form("0.70"),
    stowage_pattern: str = Form("raahe_3_3_wedge_4"),
    custom_pattern: str = Form(""),
    builder_pattern: str = Form(""),
    cargo_file: UploadFile = File(...),
):
    try:
        suffix = Path(cargo_file.filename).suffix.lower()
        if suffix not in [".csv", ".xlsx", ".xls", ".pdf"]:
            raise HTTPException(status_code=400, detail="Please upload CSV/XLSX/PDF file.")

        job_id = uuid4().hex[:10]
        upload_path = UPLOADS / f"{job_id}{suffix}"
        upload_path.write_bytes(await cargo_file.read())

        job_results = RESULTS / job_id
        job_results.mkdir(parents=True, exist_ok=True)

        cfg = {
            "ship_name": ship_name,
            "hold_name": hold_name,
            "hold_width_m": to_float(hold_width_m),
            "hold_length_m": to_float(hold_length_m),
            "coil_diameter_m": to_float(coil_diameter_m),
            "row_gap_m": to_float(row_gap_m),
            "max_stack_height_m": to_float(max_stack_height_m) if str(max_stack_height_m).strip() else None,
            "tank_top_limit_t_m2": to_float(tank_top_limit_t_m2) if str(tank_top_limit_t_m2).strip() else None,
            "center_gap_m": to_float(center_gap_m),
            "stowage_pattern": stowage_pattern,
            "custom_pattern": custom_pattern,
            "builder_pattern": builder_pattern,
            "effective_custom_pattern": builder_pattern if stowage_pattern == "builder" and builder_pattern.strip() else custom_pattern,
            "stowage_pattern_label": builder_pattern if stowage_pattern == "builder" and builder_pattern.strip() else (custom_pattern if stowage_pattern == "custom" and custom_pattern.strip() else PATTERN_LABELS.get(stowage_pattern, stowage_pattern)),
        }

        cargo = read_cargo(upload_path)
        plan, positions = make_plan(cargo, cfg)
        draw_plan(plan, positions, cfg, job_results)
        s = summary(plan, cfg)

        return {
            **s,
            "block_weights": block_weight_summary(plan),
            "coils": plan.to_dict("records"),
            "hold": {
                "width_m": cfg["hold_width_m"],
                "length_m": cfg["hold_length_m"],
                "diameter_m": cfg.get("planning_diameter_m", cfg["coil_diameter_m"]),
                "row_gap_m": cfg["row_gap_m"],
                "center_gap_m": cfg.get("center_gap_m", 0.0),
            },
            "job_id": job_id,
            "png_url": f"/results/{job_id}/loading_plan.png",
            "pdf_url": f"/results/{job_id}/loading_plan.pdf",
            "csv_url": f"/results/{job_id}/loading_plan.csv",
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
